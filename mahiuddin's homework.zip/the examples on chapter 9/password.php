<?php 

include ('header.php');


if ($_SERVER['REQUEST_METHOD'] == 'POST') {
	
	
	require(CONNECT);

	
	$errors = array();

	
	if (empty($_POST['email'])) {
		$errors['e'] = 'You forgot to enter your email address.';
	} elseif (!(filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL))) {
		$errors['e'] = 'Your email is not in a valid format.';
	} else {
		$e = mysqli_real_escape_string($link, trim($_POST['email']));
	}
	
	if (empty($_POST['pass'])) {
		$errors['p'] = 'You forgot to enter your current password.';
	} else {
		$p = mysqli_real_escape_string($link, trim($_POST['pass']));
	}
	
	if (!empty($_POST['pass1'])) {
		if ($_POST['pass1'] != $_POST['pass2']) {
			$errors['p2'] = 'Your new passwords do not match.';
		} else {
			$np = mysqli_real_escape_string($link, trim($_POST['pass1']));
			if(isset($p) && $p==$np) {
				$errors['p1'] = 'Your new password must not be the same as your current password.';
			}
		}
	} else {
		$errors['p1'] = 'You forgot to enter your new password.';
	}

	if(empty($errors)) {
		
		$q = "SELECT user_id FROM site_users WHERE email='$e' AND pass = SHA1('$p')";
		if($r = @mysqli_query($link,$q)) {
			$num =  @mysqli_num_rows($r);
			if($num == 1 ) {
			
				$row = mysqli_fetch_array($r, MYSQLI_ASSOC);

			
				mysqli_free_result($r);

				
				$q = sprintf("UPDATE site_users SET pass=SHA1('%s') WHERE user_id=%d",$np,$row['user_id']);		
				
				$r = @mysqli_query($link, $q);

				if (mysqli_affected_rows($link) == 1) {
				
					$message = "<h2>Success!</h2><p>Your password has been updated!</p>";
				} else {
					
					$message = "<h2>System Error</h2><p class='error'>Your password was not updated.<br />We apologize for any inconvenience, please <a href='javascript:history.back()'>try again</a>.</p>";
					$message .= '<p><span class="content-caption">Debugging information</span>Error message: <br />'.mysqli_error($link).'<br /><br />Query: <br />'. $q .'</p>';
				}

				
			
			
			
				echo '<div id="content" class="message">'.$message.'</div>';

				
				include ("footer.html");
				
				
				exit();

			} else {
				
				$errors['flag'] = "<div class='error-message error'><h2>Error</h2><p>The email address and password do not match those on file.<br />Please resubmit your data or <a href='index.php?chapter=9&amp;script=9.5'>register</a> as a new user.</p></div>";
			}	
		} else {
		
			$errors['flag'] = "<div class='error-message error'><h2>Error</h2><p>There was an error validating your status.<br />Please try again.</p></div>";
		}
	} else {
		
		$errors['flag'] = "<div class='error-message error'><h2>Error</h2><p>Your information could not be updated. <br />Please resubmit your data after correcting the highlighted errors.</p></div>";
	}
	

}


echo "<div id='content'>";
?>
<h1>Change Your Password</h1>
<?php echo (isset($errors['flag']))? $errors['flag'] : ''; ?>
<form action="" method="post">
	<p>
		<label for='e'>Email Address: </label>
		<input type="text" id='e' name="email" size="20" maxlength="60" value="<?php if (isset($_POST['email'])) echo $_POST['email']; ?>"  />
		<?php echo (isset($errors['e']))?'<span class="error">'.$errors['e'].'</span>' : ''; ?>
	</p>
	<p>
		<label for='p'>Current Password: </label>
		<input type="password" id='p' name="pass" size="10" maxlength="20" value="<?php if (isset($_POST['pass'])) echo $_POST['pass']; ?>"  />
		<?php echo (isset($errors['p']))?'<span class="error">'.$errors['p'].'</span>' : ''; ?>
	</p>
	<p>
		<label for='p1'>New Password: </label>
		<input type="password" id='p1' name="pass1" size="10" maxlength="20" value="<?php if (isset($_POST['pass1'])) echo $_POST['pass1']; ?>"  />
		<?php echo (isset($errors['p1']))?'<span class="error">'.$errors['p1'].'</span>' : ''; ?>
	</p>
	<p>
		<label for='p2'>Confirm New Password: </label>
		<input type="password" id='p2' name="pass2" size="10" maxlength="20" value="<?php if (isset($_POST['pass2'])) echo $_POST['pass2']; ?>"  />
		<?php echo (isset($errors['p2']))?'<span class="error">'.$errors['p2'].'</span>' : ''; ?>
	</p>
	<p>
		<input type="submit" name="submit" value="Change Password" />
	</p>
</form>
<?php
echo "</div>";
include ('footer.php');
?>
