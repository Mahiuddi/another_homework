<?php # Script 9.8 - index.php

$title = 'Welcome to this Site!';
include ('header.html');
echo "<div id='content'>";
?>

<h1>Content Header</h1>

	<p> a;sdjf a;ldfj as;dfj a;ldfj a;lsdjf a;ldf sd ;dj ;lasjdflasjfl asfjawoejr voiqjwe rwojrwel,iliojdfgih</p>
	
	<p>;dfj;sdfjasd f;lasdj flsja fkajkefjsdflkjasdjlf asdfj alsdjflakjsdflkjasdfjakldjfkljsdfjas
sdfjasjdflasjdfjakldjfklajsdfljasldfja;lsjdfljasalsdjfkljasfjaskdfa
fljasldfjaklsjflkajs;fjalsjf a;lfj alkfja ;fja s</p>

<?php
echo "</div>";
include ('footer.html');
?>