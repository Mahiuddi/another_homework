<?php
 
include ("header.html");

echo "<div id='content'>";
echo '<h1>Registered Users</h1>';

require(CONNECT);


$q = "SELECT CONCAT(last_name, ', ', first_name) AS 'User Name', DATE_FORMAT(registration_date, '%M %d, %Y') AS 'Date Registered' FROM site_users ORDER BY registration_date ASC";		


if($r = @mysqli_query ($link, $q)) { 
	
	$num = mysqli_num_rows($r);

	if($num > 0) {
	
		echo "<div class='message'>There are currently $num registered users.</div>\n";
		
		results_to_table($r,'');
	} else {
	
		echo '<p class="error-message error">There are currently no registered users.</p>';
	}

	
	mysqli_free_result($r);

} else {

	echo '<h2>Error</h2><p class="error-message error">There was an error accessing the database. Please try again later.</p>';
}

require(DISCONNECT);

echo "</div>";
include ("footer.html");
?>
