<?php 
include ('header.php');


if($_SERVER['REQUEST_METHOD'] == 'POST') {

	
	require(CONNECT);


	$errors = array();

	if (empty($_POST['first_name'])) {
		$errors['fn'] = 'Please enter a first name.';
	} else {
		$fn = mysqli_real_escape_string($link,trim($_POST['first_name']));
	}

	
	if (empty($_POST['last_name'])) {
		$errors['ln'] = 'Please enter a last name.';
	} else {
		$ln = mysqli_real_escape_string($link,trim($_POST['last_name']));
	}

	
	if (empty($_POST['email'])) {
		$errors['e'] = 'Please enter an email address.';
	} elseif (!(filter_var(trim($_POST['email']), FILTER_VALIDATE_EMAIL))) {
		$errors['e'] = 'The email is not in a valid format.';
	} else {
		$e = mysqli_real_escape_string($link,trim($_POST['email']));
	
        
		$q = "SELECT user_id FROM site_users WHERE email='$e'";
		if ($r = @mysqli_query($link, $q)) {
			if(mysqli_num_rows($r) != 0) {
				$errors['e'] = 'Sorry, that email has already been used. Please enter a different email address.';
			}
			
			mysqli_free_result($r);
		}	
	}		
	

	if(empty($errors)) { 

		
		$q= "INSERT INTO site_users (first_name,last_name,email,registration_date) VALUES ('$fn','$ln','$e',NOW())";
		

	
		if($r = mysqli_query($link,$q)) {

			if(mysqli_affected_rows($link) == 1) {
				
				$message = "<h2>Thank you!</h2><p>New user has been added succesfully!</p>";
			} else {
			
				$message = "<h2>System Error</h2><p class='error'>Your information could not be added to our database.<br />We apologize for any inconvenience, please <a href='javascript:history.back()'>try again</a>.</p>";
				$message .= '<p><span class="content-caption">Debugging information</span>Error message: <br />'.mysqli_error($link).'<br /><br />Query: <br />'. $q .'</p>';
			}
			
		

		} else {
			
			$message = '<h2>Error</h2><p class="error-message error">There was an error accessing the database. Please try again later.</p>';	
		}
		
		
		require(DISCONNECT);
		
		
		echo '<div id="content" class="message">'.$message.'</div>';

	
		
		
		exit(); 

	} else {
		$errors['flag'] = "<div class='error-message error'><h2>Error</h2><p>Your registration is not complete.<br />Please doublecheck your information and resubmit after correcting the highlighted errors.</p></div>";
	}
	
	require(DISCONNECT);
}
echo "<div id='content'>";
?>
<h1>Add New User</h1>
<?php echo (isset($errors['flag']))? $errors['flag'] : ''; ?>
<form action="" method="post">
	<p>
		<label for='fn'>First Name: </label>
		<input type="text" id='fn' name="first_name" size="15" maxlength="20" value="<?php if (isset($_POST['first_name'])) echo $_POST['first_name']; ?>" />
		<?php echo (isset($errors['fn']))?'<span class="error">'.$errors['fn'].'</span>' : ''; ?>
	</p>
	<p>
		<label for='ln'>Last Name: </label>
		<input type="text" id='ln' name="last_name" size="15" maxlength="40" value="<?php if (isset($_POST['last_name'])) echo $_POST['last_name']; ?>" />
		<?php echo (isset($errors['ln']))?'<span class="error">'.$errors['ln'].'</span>' : ''; ?></p>
	<p>
		<label for='e'>Email Address: </label>
		<input type="text" id='e' name="email" size="20" maxlength="60" value="<?php if (isset($_POST['email'])) echo $_POST['email']; ?>"  />
		<?php echo (isset($errors['e']))?'<span class="error">'.$errors['e'].'</span>' : ''; ?>
	</p>
<!-- 	<p>
		<label for='p1'>Password: </label>
		<input type="password" id='p1' name="pass1" size="10" maxlength="20" value="<?php if (isset($_POST['pass1'])) echo $_POST['pass1']; ?>"  />
		<?php echo (isset($errors['p1']))?'<span class="error">'.$errors['p1'].'</span>' : ''; ?>
	</p>
	<p>
		<label for='p2'>Confirm Password: </label>
		<input type="password" id='p2' name="pass2" size="10" maxlength="20" value="<?php if (isset($_POST['pass2'])) echo $_POST['pass2']; ?>"  />
		<?php echo (isset($errors['p2']))?'<span class="error">'.$errors['p2'].'</span>' : ''; ?>
	</p> -->
	<p>
		<input type="submit" name="submit" value="Add User" />
	</p>
</form>
<?php
echo "</div>";
include ('footer.php');
?>