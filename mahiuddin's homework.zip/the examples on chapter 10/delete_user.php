<?php //script 10.2 delete user
include ('header.php');


require(CONNECT);

echo "<div id='content'>";
echo '<h1>Delete User</h1>';

if ( (isset($_GET['id'])) && (is_numeric($_GET['id'])) ) { 
	$id = $_GET['id'];
} elseif ( (isset($_POST['id'])) && (is_numeric($_POST['id'])) ) { 
	$id = $_POST['id'];
} else { 
	$q = "SELECT CONCAT_WS(', ',last_name, first_name) AS customer, DATE_FORMAT(registration_date, '%M %d, %Y') AS dr, user_id AS id FROM site_users ORDER BY last_name ASC";		
	if($r = mysqli_query($link,$q) ){
		echo "<form action='' method='post' ><p><label for='c'>Select Customer to Delete</label>";
		echo "<select id='c' name='id'>";
		while($row = mysqli_fetch_assoc($r)) {
			echo "<option";
			echo (isset($_POST['customer']) && $_POST['customer'] == $row['customer'])? ' selected':'';
			echo " value='$row[id]'>$row[customer]</option>";
		}	
		echo "</select></p><input type='submit' value='Select'/></form>";
	} else {
		echo "We are experiencing technical difficulties. Try back later.";
	}
}


if ($_SERVER['REQUEST_METHOD'] == 'POST' || isset($id)) {

	if (isset($_POST['sure'])) {
		if($_POST['sure'] == 'Yes') { 
			$q = "DELETE FROM site_users WHERE user_id=$id LIMIT 1";		
			$r = @mysqli_query ($link, $q);
			if (mysqli_affected_rows($link) == 1) {
				echo '<p>The user has been deleted.</p>';	
			} else { 
				echo '<p class="error">The user could not be deleted due to a system error.</p>'; // Public message.
				echo '<p>' . mysqli_error($link) . '<br />Query: ' . $q . '</p>'; 
			}

		} else { 
			echo '<p>The user has NOT been deleted.</p>';
		}	
	
	} else { 
		$q = "SELECT CONCAT(last_name, ', ', first_name) FROM site_users WHERE user_id=$id";
		$r = @mysqli_query ($link, $q);

		if (mysqli_num_rows($r) == 1) { 
			$row = mysqli_fetch_array ($r, MYSQLI_NUM);
			
			
			echo "<h3>Name: $row[0]</h3>
			Are you sure you want to delete this user?";
			
			// Create the form:
			echo '<form action="" method="post">
			<input type="radio" name="sure" value="Yes" /> Yes 
			<input type="radio" name="sure" value="No" checked="checked" /> No
			<input type="submit" name="submit" value="Confirm" />
			<input type="hidden" name="id" value="' . $id . '" />
			</form>';
		} else { 
			echo '<p class="error">This page has been accessed in error.</p>';
		}
	}
} 



echo "</div>";
include ('footer.php');
?>
