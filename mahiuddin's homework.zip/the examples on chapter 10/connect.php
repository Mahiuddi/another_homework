<?php

$dbc = mysqli_connect=('localhost','root','12345678','nameofdatabase'); 
 
if($dbc){
    echo"you are connected successfully";
}else{
    echo" failed to connect to database ";
}
?>